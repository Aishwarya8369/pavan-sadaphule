"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ExternalLink, Play, Film } from "lucide-react"

const projects = [
  {
    title: "Feature Film VFX",
    category: "Compositing",
    image: "/placeholder.svg?height=300&width=500",
    description:
      "Complex compositing work for a major Hollywood feature film, including environment extensions and CG integration.",
    link: "#",
  },
  {
    title: "TV Series Visual Effects",
    category: "Compositing",
    image: "/placeholder.svg?height=300&width=500",
    description: "Episodic VFX work including set extensions, screen replacements, and atmospheric effects.",
    link: "#",
  },
  {
    title: "Digital Restoration",
    category: "Paint",
    image: "/placeholder.svg?height=300&width=500",
    description: "Detailed paint work to remove unwanted elements and restore damaged footage for a period film.",
    link: "#",
  },
  {
    title: "Clean Plate Creation",
    category: "Paint",
    image: "/placeholder.svg?height=300&width=500",
    description:
      "Creation of clean plates for complex VFX shots requiring object removal and background reconstruction.",
    link: "#",
  },
  {
    title: "3D Conversion Project",
    category: "Stereo",
    image: "/placeholder.svg?height=300&width=500",
    description: "Conversion of 2D footage to stereoscopic 3D for an action-adventure film.",
    link: "#",
  },
  {
    title: "Commercial VFX",
    category: "Compositing",
    image: "/placeholder.svg?height=300&width=500",
    description:
      "High-end compositing for a luxury brand commercial, including product integration and environment creation.",
    link: "#",
  },
]

const categories = ["All", "Compositing", "Paint", "Stereo", "Roto"]

export default function ProjectsSection() {
  const [activeCategory, setActiveCategory] = useState("All")
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const filteredProjects =
    activeCategory === "All" ? projects : projects.filter((project) => project.category === activeCategory)

  return (
    <section id="projects" className="py-20">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-teal-400 to-blue-500">
            Featured Projects
          </span>
        </h2>

        <div className="flex flex-wrap justify-center gap-2 mb-10">
          {categories.map((category) => (
            <Button
              key={category}
              variant={activeCategory === category ? "default" : "outline"}
              onClick={() => setActiveCategory(category)}
              className={
                activeCategory === category
                  ? "bg-teal-600 hover:bg-teal-700"
                  : "border-teal-600 text-teal-400 hover:bg-teal-600/10"
              }
            >
              {category}
            </Button>
          ))}
        </div>

        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: inView ? 1 : 0, y: inView ? 0 : 20 }}
          transition={{ duration: 0.8 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {filteredProjects.map((project, index) => (
            <Card
              key={index}
              className="overflow-hidden bg-gradient-to-br from-teal-900/20 to-blue-900/20 p-[1px] rounded-lg"
            >
              <div className="bg-[#0a0a0f]/60 backdrop-blur-sm rounded-lg overflow-hidden">
                <div className="relative group">
                  <img
                    src={project.image || "/placeholder.svg"}
                    alt={project.title}
                    className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <Button size="icon" className="bg-teal-600 hover:bg-teal-700 text-white rounded-full">
                      <Play className="h-5 w-5" />
                    </Button>
                  </div>
                  <div className="absolute top-2 right-2 bg-teal-600 text-white text-xs px-2 py-1 rounded">
                    {project.category}
                  </div>
                </div>
                <CardContent className="p-4">
                  <h3 className="text-xl font-semibold mb-2 text-white">{project.title}</h3>
                  <p className="text-gray-400 text-sm mb-4">{project.description}</p>
                  <a href={project.link} className="inline-flex items-center text-teal-400 hover:text-teal-300 text-sm">
                    View Project <ExternalLink className="ml-1 h-4 w-4" />
                  </a>
                </CardContent>
              </div>
            </Card>
          ))}
        </motion.div>

        <div className="text-center mt-12">
          <Button className="bg-gradient-to-r from-teal-600 to-blue-600 hover:from-teal-700 hover:to-blue-700">
            View All Projects <Film className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>
    </section>
  )
}
